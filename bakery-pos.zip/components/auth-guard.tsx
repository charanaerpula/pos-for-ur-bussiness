"use client"

import type React from "react"

import { useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import { useStore } from "@/lib/store"
import type { UserRole } from "@/lib/store"

interface AuthGuardProps {
  children: React.ReactNode
  requiredRole?: UserRole
}

export default function AuthGuard({ children, requiredRole = "employee" }: AuthGuardProps) {
  const router = useRouter()
  const pathname = usePathname()
  const { auth } = useStore()

  useEffect(() => {
    // Skip auth check for login page
    if (pathname === "/login") {
      return
    }

    // If not authenticated, redirect to login
    if (!auth.isAuthenticated) {
      router.push("/login")
      return
    }

    // Check role permissions
    if (requiredRole === "admin" && auth.role !== "admin") {
      // If admin role is required but user is not admin, redirect to dashboard
      router.push("/")
    }
  }, [auth.isAuthenticated, auth.role, pathname, requiredRole, router])

  // If on login page and already authenticated, redirect to dashboard
  useEffect(() => {
    if (pathname === "/login" && auth.isAuthenticated) {
      router.push("/")
    }
  }, [auth.isAuthenticated, pathname, router])

  return <>{children}</>
}
