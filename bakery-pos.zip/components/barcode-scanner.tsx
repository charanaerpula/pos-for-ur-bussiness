"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { BrowserMultiFormatReader } from "@zxing/library"
import { Camera, CameraOff } from "lucide-react"

interface BarcodeScannerProps {
  onScan: (result: string) => void
  continuous?: boolean
}

export default function BarcodeScanner({ onScan, continuous = false }: BarcodeScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [error, setError] = useState<string | null>(null)
  const [isScanning, setIsScanning] = useState(false)
  const [isCameraReady, setCameraReady] = useState(false)
  const readerRef = useRef<BrowserMultiFormatReader | null>(null)
  const [lastScanned, setLastScanned] = useState<string | null>(null)
  const [scanSuccess, setScanSuccess] = useState(false)
  const scanTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    // Initialize the barcode reader
    readerRef.current = new BrowserMultiFormatReader()

    // Cleanup on unmount
    return () => {
      if (readerRef.current) {
        readerRef.current.reset()
      }
      if (scanTimeoutRef.current) {
        clearTimeout(scanTimeoutRef.current)
      }
    }
  }, [])

  const startScanning = async () => {
    if (!readerRef.current) return

    try {
      setError(null)
      setIsScanning(true)
      setLastScanned(null)

      // Get video stream
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      })

      if (videoRef.current) {
        videoRef.current.srcObject = stream
        // Wait for video to be ready
        videoRef.current.onloadedmetadata = () => {
          setCameraReady(true)
        }
      }

      // Start continuous scanning
      readerRef.current.decodeFromVideoDevice(undefined, videoRef.current!, (result) => {
        if (result) {
          const scannedText = result.getText()

          // Prevent duplicate scans within a short time period
          if (lastScanned !== scannedText) {
            // Provide feedback that a code was scanned
            navigator.vibrate?.(100) // Vibrate if supported
            setScanSuccess(true)
            setLastScanned(scannedText)
            onScan(scannedText)

            // Reset success indicator after a short delay
            if (scanTimeoutRef.current) {
              clearTimeout(scanTimeoutRef.current)
            }
            scanTimeoutRef.current = setTimeout(() => {
              setScanSuccess(false)
            }, 1500)

            // If not in continuous mode, stop scanning
            if (!continuous) {
              stopScanning()
            }
          }
        }
      })
    } catch (err) {
      setError("Could not access camera. Please ensure you've granted camera permissions.")
      setIsScanning(false)
      console.error("Camera access error:", err)
    }
  }

  const stopScanning = () => {
    if (readerRef.current) {
      readerRef.current.reset()
    }

    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks()
      tracks.forEach((track) => track.stop())
      videoRef.current.srcObject = null
    }

    setIsScanning(false)
    setCameraReady(false)
    setScanSuccess(false)
  }

  return (
    <div className="flex flex-col items-center">
      {error && <div className="mb-4 p-3 bg-red-100 text-red-800 rounded-md text-sm">{error}</div>}

      <div className="relative w-full max-w-md aspect-video bg-black rounded-lg overflow-hidden mb-4">
        {isScanning ? (
          <>
            <video ref={videoRef} className="w-full h-full object-cover" autoPlay playsInline />
            {isCameraReady && (
              <div className="absolute inset-0 pointer-events-none">
                <div
                  className={`absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 border-2 ${scanSuccess ? "border-green-500" : "border-white"} rounded-lg transition-colors duration-300`}
                ></div>
                <div
                  className={`absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-1 ${scanSuccess ? "bg-green-500" : "bg-red-500"} opacity-70`}
                ></div>

                {scanSuccess && lastScanned && (
                  <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-4 py-2 rounded-full text-sm font-medium">
                    Product added to cart
                  </div>
                )}
              </div>
            )}
          </>
        ) : (
          <div className="absolute inset-0 flex items-center justify-center text-white">
            <div className="text-center">
              <Camera className="h-10 w-10 mx-auto mb-2" />
              <p>Camera preview will appear here</p>
            </div>
          </div>
        )}
      </div>

      <div className="flex gap-2">
        {!isScanning ? (
          <Button onClick={startScanning} type="button" className="w-full">
            <Camera className="mr-2 h-4 w-4" />
            Start Scanner
          </Button>
        ) : (
          <Button onClick={stopScanning} variant="destructive" type="button" className="w-full">
            <CameraOff className="mr-2 h-4 w-4" />
            Stop Scanner
          </Button>
        )}
      </div>

      {continuous && isScanning && (
        <p className="text-sm text-muted-foreground mt-2 text-center">
          Scanner is in continuous mode. Products will be added automatically when scanned.
        </p>
      )}
    </div>
  )
}
