"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { BarChart, CakeSlice, Home, LogOut, Menu, Package, Settings, Users, X, ShoppingBag } from "lucide-react"
import { cn } from "@/lib/utils"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useStore } from "@/lib/store"
import { Badge } from "@/components/ui/badge"
import { ThemeToggle } from "@/components/theme-toggle"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { toast } from "@/components/ui/use-toast"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export default function Sidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const { auth } = useStore()
  const [shouldRender, setShouldRender] = useState(true)
  const [collapsed, setCollapsed] = useState(false)

  useEffect(() => {
    setShouldRender(pathname !== "/login")

    // Check if sidebar state is saved in localStorage
    const savedState = localStorage.getItem("sidebar-collapsed")
    if (savedState) {
      setCollapsed(savedState === "true")
    }

    // Check screen size for initial state on mobile
    const handleResize = () => {
      if (window.innerWidth < 1024) {
        setCollapsed(true)
      }
    }

    handleResize()
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [pathname])

  // Skip rendering sidebar on login page
  if (!shouldRender) {
    return null
  }

  const isAdmin = auth.role === "admin"

  const routes = [
    {
      label: "Dashboard",
      icon: Home,
      href: "/",
      roles: ["admin", "employee"],
    },
    {
      label: "Billing",
      icon: ShoppingBag,
      href: "/billing",
      roles: ["admin", "employee"],
    },
    {
      label: "Inventory",
      icon: Package,
      href: "/inventory",
      roles: ["admin", "employee"],
    },
    {
      label: "Reports",
      icon: BarChart,
      href: "/reports",
      roles: ["admin", "employee"],
    },
    {
      label: "Users",
      icon: Users,
      href: "/users",
      roles: ["admin"],
    },
    {
      label: "Settings",
      icon: Settings,
      href: "/settings",
      roles: ["admin"],
    },
  ]

  // Filter routes based on user role
  const filteredRoutes = routes.filter((route) => route.roles.includes(auth.role))

  // Improved logout handler with error handling
  const handleLogout = () => {
    try {
      auth.logout()
      // Use a small timeout to ensure state is updated before navigation
      setTimeout(() => {
        router.push("/login")
        toast({
          title: "Logged out successfully",
          description: "You have been logged out of the system",
        })
      }, 100)
    } catch (error) {
      console.error("Logout error:", error)
      toast({
        title: "Logout failed",
        description: "There was an issue logging out. Please try again.",
        variant: "destructive",
      })
    }
  }

  const toggleCollapse = () => {
    const newState = !collapsed
    setCollapsed(newState)
    localStorage.setItem("sidebar-collapsed", String(newState))
  }

  return (
    <>
      {/* Desktop Sidebar */}
      <div
        className={cn(
          "hidden lg:flex h-screen flex-col border-r bg-card transition-all duration-300 ease-in-out z-30",
          collapsed ? "w-[80px]" : "w-[280px]",
        )}
      >
        <div className="flex h-16 items-center border-b px-4 justify-between">
          <Link href="/" className="flex items-center gap-2 overflow-hidden">
            <CakeSlice className="h-6 w-6 text-primary flex-shrink-0" />
            <span className={cn("font-bold text-xl transition-opacity", collapsed ? "opacity-0 w-0" : "opacity-100")}>
              BakeryPOS
            </span>
          </Link>
          <Button variant="ghost" size="icon" onClick={toggleCollapse} className="h-8 w-8">
            <Menu className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex-1 overflow-auto py-6 px-3">
          <nav className="grid items-start gap-2">
            <TooltipProvider delayDuration={0}>
              {filteredRoutes.map((route) => (
                <Tooltip key={route.href}>
                  <TooltipTrigger asChild>
                    <Link
                      href={route.href}
                      className={cn(
                        "group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all hover:bg-accent",
                        pathname === route.href
                          ? "bg-primary/10 text-primary dark:bg-primary/20"
                          : "text-muted-foreground hover:text-foreground",
                      )}
                    >
                      <route.icon
                        className={cn(
                          "h-5 w-5 flex-shrink-0",
                          pathname === route.href
                            ? "text-primary"
                            : "text-muted-foreground group-hover:text-foreground",
                        )}
                      />
                      <span className={cn("transition-opacity", collapsed ? "opacity-0 w-0 hidden" : "opacity-100")}>
                        {route.label}
                      </span>
                    </Link>
                  </TooltipTrigger>
                  {collapsed && <TooltipContent side="right">{route.label}</TooltipContent>}
                </Tooltip>
              ))}
            </TooltipProvider>
          </nav>
        </div>

        <div className="border-t p-4">
          <div className={cn("flex items-center", collapsed ? "justify-center" : "justify-between")}>
            {!collapsed && (
              <div className="flex items-center gap-3">
                <Avatar className="h-9 w-9">
                  <AvatarFallback className="bg-primary/10 text-primary">
                    {auth.currentUser?.name.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium leading-none">{auth.currentUser?.name}</p>
                  <p className="text-xs text-muted-foreground capitalize">{auth.role}</p>
                </div>
              </div>
            )}

            <div className="flex items-center gap-1">
              {!collapsed && <ThemeToggle />}
              <TooltipProvider delayDuration={0}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" onClick={handleLogout} className="h-8 w-8 text-red-500">
                      <LogOut className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side={collapsed ? "right" : "bottom"}>Logout</TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>

          {isAdmin && !collapsed && (
            <Badge
              variant="outline"
              className="mt-2 w-full justify-center bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-200 dark:border-red-800/30"
            >
              Admin Mode
            </Badge>
          )}
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 border-t bg-card z-50">
        <div className="flex justify-around items-center h-16">
          {filteredRoutes.slice(0, 4).map((route) => (
            <Link
              key={route.href}
              href={route.href}
              className={cn(
                "flex flex-col items-center justify-center gap-1 py-1 px-3 rounded-md",
                pathname === route.href ? "text-primary" : "text-muted-foreground",
              )}
            >
              <route.icon className="h-5 w-5" />
              <span className="text-xs">{route.label}</span>
            </Link>
          ))}

          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="h-12 w-12 rounded-full">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Open menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[80%] sm:w-[350px] p-0">
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between border-b p-4">
                  <div className="flex items-center gap-2">
                    <CakeSlice className="h-6 w-6 text-primary" />
                    <span className="font-bold text-xl">BakeryPOS</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ThemeToggle />
                    <Button variant="ghost" size="icon" onClick={() => setOpen(false)}>
                      <X className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
                <div className="py-4 border-b">
                  <div className="flex items-center gap-4 px-4">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {auth.currentUser?.name.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{auth.currentUser?.name}</p>
                      <p className="text-sm text-muted-foreground capitalize">{auth.role}</p>
                    </div>
                    {isAdmin && (
                      <Badge
                        variant="outline"
                        className="ml-auto bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-200 dark:border-red-800/30"
                      >
                        Admin
                      </Badge>
                    )}
                  </div>
                </div>
                <nav className="flex-1 py-6 px-4">
                  <div className="grid gap-2">
                    {filteredRoutes.map((route) => (
                      <Link
                        key={route.href}
                        href={route.href}
                        onClick={() => setOpen(false)}
                        className={cn(
                          "flex items-center gap-4 rounded-lg px-4 py-3 transition-all",
                          pathname === route.href
                            ? "bg-primary/10 text-primary dark:bg-primary/20"
                            : "text-muted-foreground hover:bg-accent hover:text-foreground",
                        )}
                      >
                        <route.icon className="h-5 w-5" />
                        {route.label}
                      </Link>
                    ))}
                  </div>
                </nav>
                <div className="border-t p-4">
                  <Button variant="outline" className="w-full" onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Logout
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </>
  )
}
