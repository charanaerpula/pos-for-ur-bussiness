"use client"

import type React from "react"
import { useStore } from "@/lib/store"
import Image from "next/image"

interface BusinessHeaderProps {
  showMetrics?: boolean
  children?: React.ReactNode
}

export default function BusinessHeader({ showMetrics = true, children }: BusinessHeaderProps) {
  const { businessSettings } = useStore()

  return (
    <div className="flex flex-col items-center text-center mb-6">
      <div className="flex items-center gap-3 mb-2">
        {businessSettings.logoUrl ? (
          <div className="w-12 h-12 relative">
            <Image
              src={businessSettings.logoUrl || "/placeholder.svg"}
              alt={businessSettings.businessName}
              fill
              style={{ objectFit: "contain" }}
              className="rounded-md"
            />
          </div>
        ) : null}
        <div className="flex flex-col items-start">
          <h1 className="text-2xl md:text-3xl font-bold" style={{ color: businessSettings.primaryColor }}>
            {businessSettings.businessName}
          </h1>
          <p className="text-sm text-muted-foreground">{businessSettings.tagline}</p>
        </div>
      </div>

      {children}
    </div>
  )
}
