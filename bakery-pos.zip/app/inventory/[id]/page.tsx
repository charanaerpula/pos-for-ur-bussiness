"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Barcode, Trash } from "lucide-react"
import BarcodeScanner from "@/components/barcode-scanner"
import { useStore } from "@/lib/store"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import AuthGuard from "@/components/auth-guard"

export default function EditInventoryPage() {
  const router = useRouter()
  const params = useParams()
  const productId = params.id as string

  const { products, updateProduct, deleteProduct, categories } = useStore()
  const [showScanner, setShowScanner] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    sku: "",
    price: "",
    cost: "",
    stock: "",
    category: "",
    description: "",
  })

  // Load product data
  useEffect(() => {
    const product = products.find((p) => p.id === productId)
    if (product) {
      setFormData({
        name: product.name,
        sku: product.sku,
        price: product.price.toString(),
        cost: product.cost.toString(),
        stock: product.stock.toString(),
        category: product.category,
        description: product.description || "",
      })
    } else {
      toast({
        title: "Error",
        description: "Product not found",
        variant: "destructive",
      })
      router.push("/inventory")
    }
  }, [productId, products, router])

  const handleScan = (result: string) => {
    setFormData((prev) => ({ ...prev, sku: result }))
    setShowScanner(false)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target
    setFormData((prev) => ({ ...prev, [id]: value }))
  }

  const handleSelectChange = (value: string) => {
    setFormData((prev) => ({ ...prev, category: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!formData.name || !formData.sku || !formData.price || !formData.stock || !formData.category) {
      toast({
        title: "Error",
        description: "Please fill all required fields",
        variant: "destructive",
      })
      return
    }

    // Update product
    updateProduct(productId, {
      name: formData.name,
      sku: formData.sku,
      price: Number.parseFloat(formData.price),
      cost: formData.cost ? Number.parseFloat(formData.cost) : 0,
      stock: Number.parseInt(formData.stock),
      category: formData.category,
      description: formData.description,
    })

    toast({
      title: "Success",
      description: "Product updated successfully",
    })

    // Redirect to inventory page
    router.push("/inventory")
  }

  const handleDelete = () => {
    deleteProduct(productId)
    toast({
      title: "Success",
      description: "Product deleted successfully",
    })
    router.push("/inventory")
  }

  return (
    <AuthGuard requiredRole="admin">
      <div className="flex min-h-screen flex-col">
        <header className="bg-white shadow-sm dark:bg-gray-950 dark:border-b dark:border-gray-800">
          <div className="container mx-auto p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Link href="/inventory">
                  <Button variant="ghost" size="sm">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Back
                  </Button>
                </Link>
                <h1 className="text-xl font-bold ml-2">Edit Product</h1>
              </div>

              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" size="sm" className="text-red-500">
                    <Trash className="mr-2 h-4 w-4" />
                    Delete
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This action cannot be undone. This will permanently delete the product from your inventory.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDelete} className="bg-red-500 hover:bg-red-600">
                      Delete
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        </header>
        <main className="flex-1 container mx-auto p-4 md:p-6">
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle>Product Information</CardTitle>
              <CardDescription>Update the details of this product</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-6" onSubmit={handleSubmit}>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Product Name*</Label>
                    <Input
                      id="name"
                      placeholder="e.g. Chocolate Croissant"
                      value={formData.name}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="sku">SKU/Barcode*</Label>
                    <div className="flex gap-2">
                      <Input id="sku" placeholder="e.g. CC001" value={formData.sku} onChange={handleChange} required />
                      <Button type="button" variant="outline" size="icon" onClick={() => setShowScanner(!showScanner)}>
                        <Barcode className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="price">Price*</Label>
                      <Input
                        id="price"
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        value={formData.price}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cost">Cost</Label>
                      <Input
                        id="cost"
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        value={formData.cost}
                        onChange={handleChange}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="stock">Stock*</Label>
                      <Input
                        id="stock"
                        type="number"
                        placeholder="0"
                        value={formData.stock}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="category">Category*</Label>
                      <Select value={formData.category} onValueChange={handleSelectChange} required>
                        <SelectTrigger id="category">
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category.id} value={category.slug}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Input
                      id="description"
                      placeholder="Product description"
                      value={formData.description}
                      onChange={handleChange}
                    />
                  </div>
                </div>

                {showScanner && (
                  <div className="mt-4 p-4 border rounded-lg">
                    <h3 className="text-lg font-medium mb-2">Scan Barcode</h3>
                    <BarcodeScanner onScan={handleScan} continuous={false} />
                  </div>
                )}

                <div className="flex flex-col sm:flex-row justify-end gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full sm:w-auto"
                    onClick={() => router.push("/inventory")}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" className="w-full sm:w-auto">
                    Save Changes
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </main>
        <Toaster />
      </div>
    </AuthGuard>
  )
}
