"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Barcode, Save } from "lucide-react"
import BarcodeScanner from "@/components/barcode-scanner"
import { useStore } from "@/lib/store"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import AuthGuard from "@/components/auth-guard"
import { Separator } from "@/components/ui/separator"

export default function AddInventoryPage() {
  const router = useRouter()
  const { addProduct, categories } = useStore()
  const [showScanner, setShowScanner] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    sku: "",
    price: "",
    cost: "",
    stock: "",
    category: "",
    description: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleScan = (result: string) => {
    setFormData((prev) => ({ ...prev, sku: result }))
    setShowScanner(false)
    toast({
      title: "Barcode Scanned",
      description: `SKU set to: ${result}`,
    })
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target
    setFormData((prev) => ({ ...prev, [id]: value }))
  }

  const handleSelectChange = (value: string) => {
    setFormData((prev) => ({ ...prev, category: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Validate form
    if (!formData.name || !formData.sku || !formData.price || !formData.stock || !formData.category) {
      toast({
        title: "Error",
        description: "Please fill all required fields",
        variant: "destructive",
      })
      setIsSubmitting(false)
      return
    }

    // Add product
    setTimeout(() => {
      addProduct({
        name: formData.name,
        sku: formData.sku,
        price: Number.parseFloat(formData.price),
        cost: formData.cost ? Number.parseFloat(formData.cost) : 0,
        stock: Number.parseInt(formData.stock),
        category: formData.category,
        description: formData.description,
      })

      toast({
        title: "Success",
        description: "Product added successfully",
      })

      // Redirect to inventory page
      router.push("/inventory")
    }, 600)
  }

  // Get category name from slug
  const getCategoryName = (slug: string) => {
    const category = categories.find((cat) => cat.slug === slug)
    return category ? category.name : slug
  }

  return (
    <AuthGuard requiredRole="admin">
      <div className="flex min-h-screen flex-col">
        <header className="bg-white shadow-sm dark:bg-gray-950 dark:border-b dark:border-gray-800">
          <div className="container mx-auto p-4">
            <div className="flex items-center">
              <Link href="/inventory">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Inventory
                </Button>
              </Link>
            </div>
          </div>
        </header>
        <main className="flex-1 container mx-auto p-4 md:p-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Add New Product</h2>
              <p className="text-muted-foreground">Enter the details of the new product to add to your inventory.</p>
            </div>
          </div>

          <Card className="max-w-3xl mx-auto border-none shadow-md dark:shadow-gray-800/10">
            <CardHeader>
              <CardTitle>Product Information</CardTitle>
              <CardDescription>Fill in the product details below. Fields marked with * are required.</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-8" onSubmit={handleSubmit}>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium">Basic Information</h3>
                    <p className="text-sm text-muted-foreground">The core details about your product.</p>
                    <Separator className="my-4" />

                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="name" className="font-medium">
                          Product Name*
                        </Label>
                        <Input
                          id="name"
                          placeholder="e.g. Chocolate Croissant"
                          value={formData.name}
                          onChange={handleChange}
                          required
                          className="h-10"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="sku" className="font-medium">
                          SKU/Barcode*
                        </Label>
                        <div className="flex gap-2">
                          <Input
                            id="sku"
                            placeholder="e.g. CC001"
                            value={formData.sku}
                            onChange={handleChange}
                            required
                            className="h-10"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            size="icon"
                            onClick={() => setShowScanner(!showScanner)}
                            className="h-10 w-10 flex-shrink-0"
                          >
                            <Barcode className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium">Pricing & Inventory</h3>
                    <p className="text-sm text-muted-foreground">Set the price and stock information.</p>
                    <Separator className="my-4" />

                    <div className="grid gap-4 md:grid-cols-3">
                      <div className="space-y-2">
                        <Label htmlFor="price" className="font-medium">
                          Price*
                        </Label>
                        <Input
                          id="price"
                          type="number"
                          step="0.01"
                          placeholder="0.00"
                          value={formData.price}
                          onChange={handleChange}
                          required
                          className="h-10"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cost" className="font-medium">
                          Cost
                        </Label>
                        <Input
                          id="cost"
                          type="number"
                          step="0.01"
                          placeholder="0.00"
                          value={formData.cost}
                          onChange={handleChange}
                          className="h-10"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="stock" className="font-medium">
                          Initial Stock*
                        </Label>
                        <Input
                          id="stock"
                          type="number"
                          placeholder="0"
                          value={formData.stock}
                          onChange={handleChange}
                          required
                          className="h-10"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium">Additional Details</h3>
                    <p className="text-sm text-muted-foreground">Categorize and describe your product.</p>
                    <Separator className="my-4" />

                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="category" className="font-medium">
                          Category*
                        </Label>
                        <Select value={formData.category} onValueChange={handleSelectChange} required>
                          <SelectTrigger id="category" className="h-10">
                            <SelectValue placeholder="Select a category" />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map((category) => (
                              <SelectItem key={category.id} value={category.slug} className="capitalize">
                                {category.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="description" className="font-medium">
                          Description
                        </Label>
                        <Input
                          id="description"
                          placeholder="Product description"
                          value={formData.description}
                          onChange={handleChange}
                          className="h-10"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {showScanner && (
                  <div className="p-4 border rounded-lg bg-muted/30">
                    <h3 className="text-lg font-medium mb-2">Scan Barcode</h3>
                    <BarcodeScanner onScan={handleScan} continuous={false} />
                  </div>
                )}

                <div className="flex flex-col sm:flex-row justify-end gap-2 pt-4 border-t dark:border-gray-800">
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full sm:w-auto"
                    onClick={() => router.push("/inventory")}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" className="w-full sm:w-auto" disabled={isSubmitting}>
                    {isSubmitting ? (
                      <>Saving...</>
                    ) : (
                      <>
                        <Save className="mr-2 h-4 w-4" />
                        Save Product
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </main>
        <Toaster />
      </div>
    </AuthGuard>
  )
}
