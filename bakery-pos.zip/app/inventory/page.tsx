"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Edit, Plus, Search, Tag, ArrowUpRight } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { useStore } from "@/lib/store"
import { useState } from "react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

export default function InventoryPage() {
  const { products, auth, categories } = useStore()
  const [searchTerm, setSearchTerm] = useState("")
  const isAdmin = auth.role === "admin"

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.category.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Get category name from slug
  const getCategoryName = (slug: string) => {
    const category = categories.find((cat) => cat.slug === slug)
    return category ? category.name : slug
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-white shadow-sm dark:bg-gray-950 dark:border-b dark:border-gray-800">
        <div className="container mx-auto p-4">
          <h1 className="text-xl font-bold">Inventory Management</h1>
        </div>
      </header>
      <main className="flex-1 container mx-auto p-4 md:p-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Products</h2>
            <p className="text-muted-foreground">Manage your inventory and stock levels.</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search inventory..."
                className="w-full pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            {isAdmin && (
              <Link href="/inventory/add">
                <Button className="w-full sm:w-auto">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Product
                </Button>
              </Link>
            )}
          </div>
        </div>

        {products.length === 0 ? (
          <div className="text-center py-12 bg-muted/30 rounded-lg border border-dashed">
            <div className="flex flex-col items-center justify-center">
              <Tag className="h-12 w-12 text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-medium mb-2">No products in inventory</h3>
              <p className="text-muted-foreground mb-6 max-w-md">
                Add your first product to get started with inventory management
              </p>
              {isAdmin && (
                <Link href="/inventory/add">
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Product
                  </Button>
                </Link>
              )}
            </div>
          </div>
        ) : (
          <>
            {/* Mobile Card View */}
            <div className="grid gap-4 md:hidden">
              {filteredProducts.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground">No products match your search</div>
              ) : (
                filteredProducts.map((item) => (
                  <Card key={item.id} className="overflow-hidden border-none shadow-md dark:shadow-gray-800/10">
                    <CardContent className="p-0">
                      <div className="flex justify-between items-start p-4 border-b dark:border-gray-800">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10">
                            <AvatarFallback className="bg-primary/10 text-primary">
                              {item.name.charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-medium">{item.name}</h3>
                            <p className="text-xs text-muted-foreground">SKU: {item.sku}</p>
                          </div>
                        </div>
                        {isAdmin && (
                          <Link href={`/inventory/${item.id}`}>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <ArrowUpRight className="h-4 w-4" />
                            </Button>
                          </Link>
                        )}
                      </div>
                      <div className="grid grid-cols-3 gap-2 p-4">
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Price</p>
                          <p className="font-medium">{item.price.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Stock</p>
                          <p className={item.stock < 10 ? "text-red-500 font-medium" : "font-medium"}>{item.stock}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Category</p>
                          <Badge variant="outline" className="mt-1 capitalize">
                            {getCategoryName(item.category)}
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>

            {/* Desktop Table View */}
            <Card className="hidden md:block border-none shadow-md dark:shadow-gray-800/10">
              <CardHeader className="pb-0">
                <CardTitle>All Products</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>SKU</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Stock</TableHead>
                        <TableHead>Category</TableHead>
                        {isAdmin && <TableHead className="text-right">Actions</TableHead>}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredProducts.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={isAdmin ? 6 : 5} className="text-center py-6 text-muted-foreground">
                            No products match your search
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredProducts.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell className="font-medium">{item.name}</TableCell>
                            <TableCell>{item.sku}</TableCell>
                            <TableCell>{item.price.toFixed(2)}</TableCell>
                            <TableCell className={item.stock < 10 ? "text-red-500 font-medium" : ""}>
                              {item.stock}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="capitalize">
                                {getCategoryName(item.category)}
                              </Badge>
                            </TableCell>
                            {isAdmin && (
                              <TableCell className="text-right">
                                <Link href={`/inventory/${item.id}`}>
                                  <Button variant="ghost" size="sm" className="gap-1">
                                    <Edit className="h-4 w-4" />
                                    <span>Edit</span>
                                  </Button>
                                </Link>
                              </TableCell>
                            )}
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </main>
    </div>
  )
}
