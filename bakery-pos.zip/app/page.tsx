"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  BarChart,
  DollarSign,
  Package,
  Plus,
  ArrowUpRight,
  TrendingUp,
  ShoppingBag,
  Calendar,
  Users,
  AlertTriangle,
  ChevronRight,
  Clock,
} from "lucide-react"
import { useStore } from "@/lib/store"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Home() {
  const { products, getTotalSales, getTodaySalesCount, getLowStockProducts, businessSettings, sales, categories } =
    useStore()
  const lowStockProducts = getLowStockProducts()

  // Calculate sales growth (comparing today with yesterday)
  const todaySales = getTodaySalesCount()
  const yesterdaySales = sales.filter((sale) => {
    const saleDate = new Date(sale.date)
    const yesterday = new Date()
    yesterday.setDate(yesterday.getDate() - 1)
    yesterday.setHours(0, 0, 0, 0)

    const saleDay = new Date(saleDate)
    saleDay.setHours(0, 0, 0, 0)

    return saleDay.getTime() === yesterday.getTime()
  }).length

  const salesGrowth =
    yesterdaySales > 0 ? Math.round(((todaySales - yesterdaySales) / yesterdaySales) * 100) : todaySales > 0 ? 100 : 0

  // Get recent sales
  const recentSales = [...sales].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 5)

  // Calculate total inventory value
  const inventoryValue = products.reduce((total, product) => total + product.price * product.stock, 0)

  // Get category distribution
  const categoryDistribution = categories
    .map((category) => {
      const productsInCategory = products.filter((product) => product.category === category.slug)
      const count = productsInCategory.length
      const value = productsInCategory.reduce((total, product) => total + product.price * product.stock, 0)
      return {
        name: category.name,
        slug: category.slug,
        count,
        value,
      }
    })
    .sort((a, b) => b.value - a.value)

  return (
    <div className="page-container">
      <header className="page-header">
        <div className="container mx-auto p-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold">{businessSettings.businessName}</h1>
              <p className="text-muted-foreground">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
            </div>
            <div className="flex items-center gap-3">
              <Link href="/billing">
                <Button className="gap-2">
                  <ShoppingBag className="h-4 w-4" />
                  New Sale
                </Button>
              </Link>
              <Link href="/inventory/add">
                <Button variant="outline" className="gap-2">
                  <Plus className="h-4 w-4" />
                  Add Product
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="page-content">
        <div className="flex flex-col gap-6">
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="dashboard-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex flex-col gap-1">
                    <span className="text-sm font-medium text-muted-foreground">Total Revenue</span>
                    <span className="text-2xl font-bold">
                      {businessSettings.currency}
                      {getTotalSales().toLocaleString("en-IN")}
                    </span>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <DollarSign className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span>Daily Target</span>
                    <span>₹10,000</span>
                  </div>
                  <Progress value={Math.min((getTotalSales() / 10000) * 100, 100)} className="h-1.5" />
                </div>
              </CardContent>
            </Card>

            <Card className="dashboard-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex flex-col gap-1">
                    <span className="text-sm font-medium text-muted-foreground">Today's Orders</span>
                    <span className="text-2xl font-bold">{getTodaySalesCount()}</span>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-green-500/10 flex items-center justify-center">
                    <ShoppingBag className="h-6 w-6 text-green-500" />
                  </div>
                </div>
                <div className="mt-4 flex items-center gap-2">
                  <Badge variant={salesGrowth >= 0 ? "success" : "destructive"} className="h-6">
                    {salesGrowth >= 0 ? (
                      <TrendingUp className="h-3.5 w-3.5 mr-1" />
                    ) : (
                      <TrendingUp className="h-3.5 w-3.5 mr-1 rotate-180" />
                    )}
                    {salesGrowth >= 0 ? "+" : ""}
                    {salesGrowth}%
                  </Badge>
                  <span className="text-xs text-muted-foreground">vs yesterday</span>
                </div>
              </CardContent>
            </Card>

            <Card className="dashboard-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex flex-col gap-1">
                    <span className="text-sm font-medium text-muted-foreground">Inventory Value</span>
                    <span className="text-2xl font-bold">
                      {businessSettings.currency}
                      {inventoryValue.toLocaleString("en-IN")}
                    </span>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-blue-500/10 flex items-center justify-center">
                    <Package className="h-6 w-6 text-blue-500" />
                  </div>
                </div>
                <div className="mt-4 flex items-center gap-2">
                  <span className="text-sm">{products.length} products</span>
                  <span className="text-xs text-muted-foreground">•</span>
                  <span className="text-sm text-amber-500 flex items-center">
                    <AlertTriangle className="h-3.5 w-3.5 mr-1" />
                    {lowStockProducts.length} low stock
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card className="dashboard-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex flex-col gap-1">
                    <span className="text-sm font-medium text-muted-foreground">Categories</span>
                    <span className="text-2xl font-bold">{categories.length}</span>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-purple-500/10 flex items-center justify-center">
                    <BarChart className="h-6 w-6 text-purple-500" />
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex flex-wrap gap-1">
                    {categories.slice(0, 3).map((category) => (
                      <Badge key={category.id} variant="outline" className="capitalize">
                        {category.name}
                      </Badge>
                    ))}
                    {categories.length > 3 && <Badge variant="outline">+{categories.length - 3} more</Badge>}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Tabs defaultValue="sales">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle>Recent Activity</CardTitle>
                  <TabsList className="grid w-[240px] grid-cols-2">
                    <TabsTrigger value="sales">Sales</TabsTrigger>
                    <TabsTrigger value="inventory">Inventory</TabsTrigger>
                  </TabsList>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <TabsContent value="sales" className="m-0">
                  {recentSales.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-8 text-center">
                      <ShoppingBag className="h-12 w-12 text-muted-foreground/50 mb-4" />
                      <h3 className="text-lg font-medium">No sales yet</h3>
                      <p className="text-sm text-muted-foreground max-w-md mt-1">
                        Start making sales to see your recent activity here.
                      </p>
                    </div>
                  ) : (
                    <div className="divide-y">
                      {recentSales.map((sale) => (
                        <div key={sale.id} className="flex items-center justify-between p-4">
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                              <ShoppingBag className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <p className="font-medium">Invoice #{sale.id}</p>
                              <div className="flex items-center text-sm text-muted-foreground">
                                <Clock className="h-3.5 w-3.5 mr-1" />
                                {format(new Date(sale.date), "MMM d, h:mm a")}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-bold">
                              {businessSettings.currency}
                              {sale.total.toFixed(2)}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {sale.items.length} {sale.items.length === 1 ? "item" : "items"}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>
                <TabsContent value="inventory" className="m-0">
                  {lowStockProducts.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-8 text-center">
                      <Package className="h-12 w-12 text-muted-foreground/50 mb-4" />
                      <h3 className="text-lg font-medium">All stocked up!</h3>
                      <p className="text-sm text-muted-foreground max-w-md mt-1">
                        You don't have any low stock items at the moment. Your inventory is in good shape.
                      </p>
                    </div>
                  ) : (
                    <div className="divide-y">
                      {lowStockProducts.slice(0, 5).map((product) => (
                        <div key={product.id} className="flex items-center justify-between p-4">
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-full bg-amber-500/10 flex items-center justify-center">
                              <Package className="h-5 w-5 text-amber-500" />
                            </div>
                            <div>
                              <p className="font-medium">{product.name}</p>
                              <p className="text-sm text-muted-foreground capitalize">
                                Category:{" "}
                                {categories.find((c) => c.slug === product.category)?.name || product.category}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <Badge variant="destructive" className="mb-1">
                              {product.stock} left
                            </Badge>
                            <Link
                              href={`/inventory/${product.id}`}
                              className="text-sm text-primary flex items-center justify-end"
                            >
                              Update stock <ChevronRight className="h-3.5 w-3.5 ml-1" />
                            </Link>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>
              </CardContent>
            </Tabs>

            <Card className="dashboard-card">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Common tasks you can perform</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-4">
                <Link href="/billing" className="w-full">
                  <Button className="w-full justify-between" variant="outline">
                    <div className="flex items-center">
                      <ShoppingBag className="mr-2 h-4 w-4" />
                      <span>New Sale</span>
                    </div>
                    <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </Link>
                <Link href="/inventory/add" className="w-full">
                  <Button className="w-full justify-between" variant="outline">
                    <div className="flex items-center">
                      <Plus className="mr-2 h-4 w-4" />
                      <span>Add Product</span>
                    </div>
                    <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </Link>
                <Link href="/reports" className="w-full">
                  <Button className="w-full justify-between" variant="outline">
                    <div className="flex items-center">
                      <BarChart className="mr-2 h-4 w-4" />
                      <span>View Reports</span>
                    </div>
                    <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </Link>
                <Link href="/users" className="w-full">
                  <Button className="w-full justify-between" variant="outline">
                    <div className="flex items-center">
                      <Users className="mr-2 h-4 w-4" />
                      <span>Manage Users</span>
                    </div>
                    <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </Link>
                <Link href="/settings" className="w-full">
                  <Button className="w-full justify-between" variant="outline">
                    <div className="flex items-center">
                      <Calendar className="mr-2 h-4 w-4" />
                      <span>Business Settings</span>
                    </div>
                    <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          <Card className="dashboard-card">
            <CardHeader>
              <CardTitle>Inventory by Category</CardTitle>
              <CardDescription>Distribution of your products across categories</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {categoryDistribution.map((category) => (
                  <div key={category.slug} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium capitalize">{category.name}</h3>
                      <Badge variant="outline">{category.count} products</Badge>
                    </div>
                    <p className="text-2xl font-bold mb-2">
                      {businessSettings.currency}
                      {category.value.toLocaleString("en-IN")}
                    </p>
                    <Progress value={Math.min((category.value / inventoryValue) * 100, 100)} className="h-1.5" />
                    <p className="text-xs text-muted-foreground mt-2">
                      {Math.round((category.value / inventoryValue) * 100)}% of total inventory value
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
