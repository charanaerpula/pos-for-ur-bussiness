"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useStore } from "@/lib/store"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { Lock, User, CakeSlice, Loader2 } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"

export default function LoginPage() {
  const router = useRouter()
  const { auth, businessSettings, users } = useStore()
  const [pin, setPin] = useState("")
  const [adminPassword, setAdminPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("employee")

  const handleEmployeeLogin = () => {
    setIsLoading(true)
    setTimeout(() => {
      const success = auth.login(pin)
      if (success) {
        toast({
          title: "Login successful",
          description: "Welcome to the system",
        })
        router.push("/")
      } else {
        toast({
          title: "Login failed",
          description: "Invalid PIN. Please try again.",
          variant: "destructive",
        })
      }
      setIsLoading(false)
    }, 1000)
  }

  const handleAdminLogin = () => {
    setIsLoading(true)
    setTimeout(() => {
      const success = auth.adminLogin(adminPassword)
      if (success) {
        toast({
          title: "Admin login successful",
          description: "Welcome to the admin panel",
        })
        router.push("/")
      } else {
        toast({
          title: "Login failed",
          description: "Invalid admin password. Please try again.",
          variant: "destructive",
        })
      }
      setIsLoading(false)
    }, 1000)
  }

  const handleLogin = () => {
    if (activeTab === "employee") {
      handleEmployeeLogin()
    } else {
      handleAdminLogin()
    }
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-muted/30 dark:bg-gray-950">
      <div className="absolute top-4 right-4">
        <ThemeToggle />
      </div>

      <div className="w-full max-w-md p-4">
        <div className="flex flex-col items-center mb-8">
          <div className="flex items-center gap-2 mb-2">
            <CakeSlice className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold" style={{ color: businessSettings.primaryColor }}>
              {businessSettings.businessName}
            </h1>
          </div>
          <p className="text-muted-foreground">{businessSettings.tagline}</p>
        </div>

        <Card className="border-none shadow-lg dark:shadow-gray-800/10">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold text-center">Sign In</CardTitle>
            <CardDescription className="text-center">Enter your credentials to access the system</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="employee" className="w-full" onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger
                  value="employee"
                  className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  <User className="mr-2 h-4 w-4" />
                  Employee
                </TabsTrigger>
                <TabsTrigger
                  value="admin"
                  className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  <Lock className="mr-2 h-4 w-4" />
                  Admin
                </TabsTrigger>
              </TabsList>

              <TabsContent value="employee">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="pin">Employee PIN</Label>
                    <Input
                      id="pin"
                      type="password"
                      placeholder="Enter your PIN"
                      value={pin}
                      onChange={(e) => setPin(e.target.value)}
                      className="h-10"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2 mt-4">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, "", 0, "⌫"].map((num, index) => (
                      <Button
                        key={index}
                        type="button"
                        variant={num === "⌫" ? "destructive" : "outline"}
                        className="h-12 text-lg"
                        onClick={() => {
                          if (num === "⌫") {
                            setPin(pin.slice(0, -1))
                          } else if (num !== "") {
                            setPin(pin + num)
                          }
                        }}
                      >
                        {num}
                      </Button>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="admin">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="adminPassword">Admin Password</Label>
                    <Input
                      id="adminPassword"
                      type="password"
                      placeholder="Enter admin password"
                      value={adminPassword}
                      onChange={(e) => setAdminPassword(e.target.value)}
                      className="h-10"
                    />
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="flex flex-col gap-4">
            <Button
              onClick={handleLogin}
              disabled={isLoading || (activeTab === "employee" ? !pin : !adminPassword)}
              className="w-full"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Logging in...
                </>
              ) : (
                "Login"
              )}
            </Button>

            <div className="text-sm text-muted-foreground bg-muted/50 dark:bg-gray-800/50 p-3 rounded-md">
              {users.length > 0 && (
                <div>
                  <p className="font-medium mb-1">Demo Credentials:</p>
                  <ul className="space-y-1">
                    {users.map((user) => (
                      <li key={user.id} className="flex justify-between">
                        <span>
                          {user.name} ({user.role})
                        </span>
                        <span className="font-mono">PIN: {user.pin}</span>
                      </li>
                    ))}
                  </ul>
                  <p className="mt-2 pt-2 border-t dark:border-gray-700">
                    Admin password: <span className="font-mono">{businessSettings.adminPassword}</span>
                  </p>
                </div>
              )}
            </div>
          </CardFooter>
        </Card>
      </div>
      <Toaster />
    </div>
  )
}
