"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useStore } from "@/lib/store"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Trash2, RefreshCw, Database, Building, Save, Lock, Tag, Plus, Edit } from "lucide-react"
import AuthGuard from "@/components/auth-guard"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function SettingsPage() {
  const {
    resetProducts,
    resetSales,
    resetAllData,
    businessSettings,
    updateBusinessSettings,
    categories,
    addCategory,
    updateCategory,
    deleteCategory,
    products,
  } = useStore()
  const [isResetting, setIsResetting] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [settings, setSettings] = useState(businessSettings)
  const [newCategory, setNewCategory] = useState({ name: "", slug: "" })
  const [editingCategory, setEditingCategory] = useState<{ id: string; name: string; slug: string } | null>(null)
  const [isAddCategoryOpen, setIsAddCategoryOpen] = useState(false)
  const [isEditCategoryOpen, setIsEditCategoryOpen] = useState(false)

  const handleResetProducts = () => {
    setIsResetting(true)
    setTimeout(() => {
      resetProducts()
      toast({
        title: "Success",
        description: "All products have been deleted",
      })
      setIsResetting(false)
    }, 1000)
  }

  const handleResetSales = () => {
    setIsResetting(true)
    setTimeout(() => {
      resetSales()
      toast({
        title: "Success",
        description: "All sales history has been deleted",
      })
      setIsResetting(false)
    }, 1000)
  }

  const handleResetAllData = () => {
    setIsResetting(true)
    setTimeout(() => {
      resetAllData()
      setSettings(businessSettings) // Reset the form to default values
      toast({
        title: "Success",
        description: "All data has been reset to default",
      })
      setIsResetting(false)
    }, 1000)
  }

  const handleSettingsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setSettings((prev) => ({
      ...prev,
      [name]: name === "taxRate" ? Number.parseFloat(value) : value,
    }))
  }

  const handleSaveSettings = () => {
    setIsSaving(true)
    setTimeout(() => {
      updateBusinessSettings(settings)
      toast({
        title: "Success",
        description: "Business settings have been updated",
      })
      setIsSaving(false)
    }, 1000)
  }

  const handleAddCategory = () => {
    if (!newCategory.name || !newCategory.slug) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      })
      return
    }

    // Check if slug already exists
    if (categories.some((cat) => cat.slug === newCategory.slug)) {
      toast({
        title: "Error",
        description: "A category with this slug already exists",
        variant: "destructive",
      })
      return
    }

    addCategory(newCategory)
    setNewCategory({ name: "", slug: "" })
    setIsAddCategoryOpen(false)
    toast({
      title: "Success",
      description: "Category added successfully",
    })
  }

  const handleUpdateCategory = () => {
    if (!editingCategory || !editingCategory.name || !editingCategory.slug) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      })
      return
    }

    // Check if slug already exists (excluding the current category)
    if (categories.some((cat) => cat.slug === editingCategory.slug && cat.id !== editingCategory.id)) {
      toast({
        title: "Error",
        description: "A category with this slug already exists",
        variant: "destructive",
      })
      return
    }

    updateCategory(editingCategory.id, {
      name: editingCategory.name,
      slug: editingCategory.slug,
    })
    setEditingCategory(null)
    setIsEditCategoryOpen(false)
    toast({
      title: "Success",
      description: "Category updated successfully",
    })
  }

  const handleDeleteCategory = (id: string) => {
    // Check if any products are using this category
    const categorySlug = categories.find((cat) => cat.id === id)?.slug
    const categoryInUse = products.some((product) => product.category === categorySlug)

    if (categoryInUse) {
      toast({
        title: "Error",
        description: "Cannot delete a category that is in use by products",
        variant: "destructive",
      })
      return
    }

    deleteCategory(id)
    toast({
      title: "Success",
      description: "Category deleted successfully",
    })
  }

  const handleSlugChange = (value: string, setter: React.Dispatch<React.SetStateAction<any>>) => {
    // Convert to lowercase and replace spaces with hyphens
    const slug = value
      .toLowerCase()
      .replace(/\s+/g, "-")
      .replace(/[^a-z0-9-]/g, "")
    setter((prev: any) => ({ ...prev, slug }))
  }

  return (
    <AuthGuard requiredRole="admin">
      <div className="flex min-h-screen flex-col">
        <header className="bg-white shadow-sm dark:bg-gray-950 dark:border-b dark:border-gray-800">
          <div className="container mx-auto p-4">
            <h1 className="text-xl font-bold">Settings</h1>
          </div>
        </header>
        <main className="flex-1 container mx-auto p-4 md:p-6">
          <div className="max-w-3xl mx-auto">
            <Tabs defaultValue="business">
              <TabsList className="grid w-full grid-cols-4 mb-6">
                <TabsTrigger value="business">
                  <Building className="mr-2 h-4 w-4" />
                  Business Settings
                </TabsTrigger>
                <TabsTrigger value="categories">
                  <Tag className="mr-2 h-4 w-4" />
                  Categories
                </TabsTrigger>
                <TabsTrigger value="security">
                  <Lock className="mr-2 h-4 w-4" />
                  Security
                </TabsTrigger>
                <TabsTrigger value="data">
                  <Database className="mr-2 h-4 w-4" />
                  Data Management
                </TabsTrigger>
              </TabsList>

              <TabsContent value="business">
                <Card>
                  <CardHeader>
                    <CardTitle>Business Information</CardTitle>
                    <CardDescription>Customize your business details and appearance</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="businessName">Business Name</Label>
                        <Input
                          id="businessName"
                          name="businessName"
                          value={settings.businessName}
                          onChange={handleSettingsChange}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="tagline">Tagline</Label>
                        <Input id="tagline" name="tagline" value={settings.tagline} onChange={handleSettingsChange} />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="address">Address</Label>
                        <Input id="address" name="address" value={settings.address} onChange={handleSettingsChange} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input id="phone" name="phone" value={settings.phone} onChange={handleSettingsChange} />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="currency">Currency Symbol</Label>
                        <Input
                          id="currency"
                          name="currency"
                          value={settings.currency}
                          onChange={handleSettingsChange}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="taxRate">Tax Rate (%)</Label>
                        <Input
                          id="taxRate"
                          name="taxRate"
                          type="number"
                          min="0"
                          max="100"
                          step="0.1"
                          value={settings.taxRate}
                          onChange={handleSettingsChange}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="upiId">UPI ID</Label>
                        <Input id="upiId" name="upiId" value={settings.upiId} onChange={handleSettingsChange} />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="logoUrl">Logo URL (optional)</Label>
                        <Input
                          id="logoUrl"
                          name="logoUrl"
                          value={settings.logoUrl || ""}
                          onChange={handleSettingsChange}
                          placeholder="https://example.com/logo.png"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="primaryColor">Primary Color</Label>
                        <div className="flex gap-2">
                          <Input
                            id="primaryColor"
                            name="primaryColor"
                            value={settings.primaryColor}
                            onChange={handleSettingsChange}
                          />
                          <div
                            className="w-10 h-10 rounded-md border"
                            style={{ backgroundColor: settings.primaryColor }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <Button onClick={handleSaveSettings} disabled={isSaving}>
                        {isSaving ? (
                          <>
                            <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="mr-2 h-4 w-4" />
                            Save Settings
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="categories">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <div>
                      <CardTitle>Product Categories</CardTitle>
                      <CardDescription>Manage the categories for your products</CardDescription>
                    </div>
                    <Dialog open={isAddCategoryOpen} onOpenChange={setIsAddCategoryOpen}>
                      <DialogTrigger asChild>
                        <Button size="sm">
                          <Plus className="mr-2 h-4 w-4" />
                          Add Category
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[425px]">
                        <DialogHeader>
                          <DialogTitle>Add New Category</DialogTitle>
                          <DialogDescription>
                            Create a new category for your products. The slug is used in URLs and should be unique.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div className="grid gap-2">
                            <Label htmlFor="name">Category Name</Label>
                            <Input
                              id="name"
                              value={newCategory.name}
                              onChange={(e) => {
                                setNewCategory({ ...newCategory, name: e.target.value })
                                if (!newCategory.slug) {
                                  handleSlugChange(e.target.value, setNewCategory)
                                }
                              }}
                              placeholder="e.g. Electronics"
                            />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="slug">Category Slug</Label>
                            <Input
                              id="slug"
                              value={newCategory.slug}
                              onChange={(e) => handleSlugChange(e.target.value, setNewCategory)}
                              placeholder="e.g. electronics"
                            />
                            <p className="text-sm text-muted-foreground">
                              Used in URLs. Only lowercase letters, numbers, and hyphens.
                            </p>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setIsAddCategoryOpen(false)}>
                            Cancel
                          </Button>
                          <Button onClick={handleAddCategory}>Add Category</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Slug</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {categories.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={3} className="text-center py-6 text-muted-foreground">
                              No categories found. Add your first category to get started.
                            </TableCell>
                          </TableRow>
                        ) : (
                          categories.map((category) => (
                            <TableRow key={category.id}>
                              <TableCell className="font-medium">{category.name}</TableCell>
                              <TableCell>{category.slug}</TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => {
                                      setEditingCategory(category)
                                      setIsEditCategoryOpen(true)
                                    }}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                      <Button variant="ghost" size="icon" className="text-red-500">
                                        <Trash2 className="h-4 w-4" />
                                      </Button>
                                    </AlertDialogTrigger>
                                    <AlertDialogContent>
                                      <AlertDialogHeader>
                                        <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                        <AlertDialogDescription>
                                          This action cannot be undone. This will permanently delete the category.
                                          Categories that are in use by products cannot be deleted.
                                        </AlertDialogDescription>
                                      </AlertDialogHeader>
                                      <AlertDialogFooter>
                                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                                        <AlertDialogAction
                                          onClick={() => handleDeleteCategory(category.id)}
                                          className="bg-red-500 hover:bg-red-600"
                                        >
                                          Delete
                                        </AlertDialogAction>
                                      </AlertDialogFooter>
                                    </AlertDialogContent>
                                  </AlertDialog>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>

                <Dialog open={isEditCategoryOpen} onOpenChange={setIsEditCategoryOpen}>
                  <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                      <DialogTitle>Edit Category</DialogTitle>
                      <DialogDescription>
                        Update the category details. The slug is used in URLs and should be unique.
                      </DialogDescription>
                    </DialogHeader>
                    {editingCategory && (
                      <div className="grid gap-4 py-4">
                        <div className="grid gap-2">
                          <Label htmlFor="edit-name">Category Name</Label>
                          <Input
                            id="edit-name"
                            value={editingCategory.name}
                            onChange={(e) => {
                              setEditingCategory({ ...editingCategory, name: e.target.value })
                            }}
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="edit-slug">Category Slug</Label>
                          <Input
                            id="edit-slug"
                            value={editingCategory.slug}
                            onChange={(e) => handleSlugChange(e.target.value, setEditingCategory)}
                          />
                          <p className="text-sm text-muted-foreground">
                            Used in URLs. Only lowercase letters, numbers, and hyphens.
                          </p>
                        </div>
                      </div>
                    )}
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsEditCategoryOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleUpdateCategory}>Save Changes</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </TabsContent>

              <TabsContent value="security">
                <Card>
                  <CardHeader>
                    <CardTitle>Security Settings</CardTitle>
                    <CardDescription>Manage access control and authentication</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="adminPassword">Admin Password</Label>
                      <Input
                        id="adminPassword"
                        name="adminPassword"
                        type="password"
                        value={settings.adminPassword}
                        onChange={handleSettingsChange}
                      />
                      <p className="text-sm text-muted-foreground mt-1">
                        This password is used to access admin features
                      </p>
                    </div>

                    <div className="flex justify-end">
                      <Button onClick={handleSaveSettings} disabled={isSaving}>
                        {isSaving ? (
                          <>
                            <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="mr-2 h-4 w-4" />
                            Save Security Settings
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="data">
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>Data Management</CardTitle>
                    <CardDescription>Manage your application data</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="border-b pb-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-lg font-medium">Reset Products</h3>
                          <p className="text-sm text-muted-foreground">
                            Delete all products from your inventory. This action cannot be undone.
                          </p>
                        </div>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" className="text-red-500 border-red-200 dark:border-red-800">
                              <Trash2 className="mr-2 h-4 w-4" />
                              Reset Products
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This action will permanently delete all products from your inventory. This action cannot
                                be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={handleResetProducts}
                                className="bg-red-500 hover:bg-red-600"
                                disabled={isResetting}
                              >
                                {isResetting ? (
                                  <>
                                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                                    Resetting...
                                  </>
                                ) : (
                                  "Reset Products"
                                )}
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>

                    <div className="border-b pb-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-lg font-medium">Reset Sales History</h3>
                          <p className="text-sm text-muted-foreground">
                            Delete all sales history and reports. This action cannot be undone.
                          </p>
                        </div>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" className="text-red-500 border-red-200 dark:border-red-800">
                              <Trash2 className="mr-2 h-4 w-4" />
                              Reset Sales
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This action will permanently delete all sales history and reports. This action cannot be
                                undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={handleResetSales}
                                className="bg-red-500 hover:bg-red-600"
                                disabled={isResetting}
                              >
                                {isResetting ? (
                                  <>
                                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                                    Resetting...
                                  </>
                                ) : (
                                  "Reset Sales"
                                )}
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-lg font-medium">Reset All Data</h3>
                          <p className="text-sm text-muted-foreground">
                            Delete all data including products, sales, and settings. This action cannot be undone.
                          </p>
                        </div>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="destructive">
                              <Database className="mr-2 h-4 w-4" />
                              Reset All Data
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This action will permanently delete all data including products, sales, and settings.
                                Your application will be reset to its default state. This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={handleResetAllData}
                                className="bg-red-500 hover:bg-red-600"
                                disabled={isResetting}
                              >
                                {isResetting ? (
                                  <>
                                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                                    Resetting...
                                  </>
                                ) : (
                                  "Reset All Data"
                                )}
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
        <Toaster />
      </div>
    </AuthGuard>
  )
}
