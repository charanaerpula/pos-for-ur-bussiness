"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useStore } from "@/lib/store"
import { Toaster } from "@/components/ui/toaster"
import { format } from "date-fns"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { CakeSlice, Calendar, ChevronDown, Download, Eye, MessageSquare, Share2, X } from "lucide-react"
import QRCode from "@/components/qr-code"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { toast } from "@/components/ui/use-toast"
import Image from "next/image"

export default function ReportsPage() {
  const { sales, businessSettings } = useStore()
  const [selectedSale, setSelectedSale] = useState<string | null>(null)
  const [dateFilter, setDateFilter] = useState<string>("")

  const filteredSales = sales.filter((sale) => {
    if (!dateFilter) return true
    const saleDate = new Date(sale.date)
    const filterDate = new Date(dateFilter)
    return (
      saleDate.getDate() === filterDate.getDate() &&
      saleDate.getMonth() === filterDate.getMonth() &&
      saleDate.getFullYear() === filterDate.getFullYear()
    )
  })

  const sale = sales.find((s) => s.id === selectedSale)

  // UPI payment string with dynamic amount
  const upiString = sale
    ? `upi://pay?pa=${businessSettings.upiId}&pn=${encodeURIComponent(businessSettings.businessName)}&am=${sale.total.toFixed(0)}&cu=INR&tn=payment`
    : ""

  const handleShareWhatsApp = () => {
    if (!sale) return

    const items = sale.items
      .map(
        (item) =>
          `${item.name} x${item.quantity} - ${businessSettings.currency}${(item.price * item.quantity).toFixed(2)}`,
      )
      .join("\n")

    const billText = `
*INVOICE: ${sale.id}*
*Date:* ${format(new Date(sale.date), "dd MMM yyyy, hh:mm a")}

*ITEMS:*
${items}

*Subtotal:* ${businessSettings.currency}${sale.subtotal.toFixed(2)}
*Tax (${businessSettings.taxRate}%):* ${businessSettings.currency}${sale.tax.toFixed(2)}
*Total:* ${businessSettings.currency}${sale.total.toFixed(2)}

Thank you for your business!
Powered by ${businessSettings.businessName}
    `.trim()

    // Encode the text for WhatsApp
    const encodedText = encodeURIComponent(billText)
    const whatsappUrl = `https://wa.me/?text=${encodedText}`

    // Open WhatsApp in a new tab
    window.open(whatsappUrl, "_blank")

    toast({
      title: "Bill shared",
      description: "The bill has been shared via WhatsApp",
    })
  }

  const handleDownloadBill = () => {
    if (!sale) return

    const items = sale.items
      .map(
        (item) =>
          `${item.name} x${item.quantity} - ${businessSettings.currency}${(item.price * item.quantity).toFixed(2)}`,
      )
      .join("\n")

    const billText = `
INVOICE: ${sale.id}
Date: ${format(new Date(sale.date), "dd MMM yyyy, hh:mm a")}

ITEMS:
${items}

Subtotal: ${businessSettings.currency}${sale.subtotal.toFixed(2)}
Tax (${businessSettings.taxRate}%): ${businessSettings.currency}${sale.tax.toFixed(2)}
Total: ${businessSettings.currency}${sale.total.toFixed(2)}

Thank you for your business!
Powered by ${businessSettings.businessName}
    `.trim()

    // Create a blob and download it
    const blob = new Blob([billText], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `Invoice-${sale.id}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "Bill downloaded",
      description: "The bill has been downloaded as a text file",
    })
  }

  const handleShareSMS = () => {
    if (!sale) return

    const items = sale.items
      .map(
        (item) =>
          `${item.name} x${item.quantity} - ${businessSettings.currency}${(item.price * item.quantity).toFixed(2)}`,
      )
      .join(", ")

    const billText = `Invoice: ${sale.id}. Total: ${businessSettings.currency}${sale.total.toFixed(2)}. Items: ${items}. Thank you for your business!`

    // Create SMS URI
    const smsUri = `sms:?body=${encodeURIComponent(billText)}`

    // Open in a new tab
    window.open(smsUri, "_blank")

    toast({
      title: "SMS prepared",
      description: "SMS app has been opened with the bill details",
    })
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-white shadow-sm">
        <div className="container mx-auto p-4">
          <h1 className="text-xl font-bold">Sales History</h1>
        </div>
      </header>
      <main className="flex-1 container mx-auto p-4 md:p-6">
        <Card className="mb-6">
          <CardHeader>
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <CardTitle>Sales History</CardTitle>
                <CardDescription>View and manage your past sales</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Calendar className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="date"
                    className="pl-8"
                    value={dateFilter}
                    onChange={(e) => setDateFilter(e.target.value)}
                  />
                </div>
                {dateFilter && (
                  <Button variant="ghost" size="sm" onClick={() => setDateFilter("")}>
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {filteredSales.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No sales history found</p>
                {dateFilter && (
                  <p className="text-sm text-muted-foreground mt-2">Try changing the date filter or adding new sales</p>
                )}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">Invoice</th>
                      <th className="text-left py-3 px-4">Date</th>
                      <th className="text-left py-3 px-4">Items</th>
                      <th className="text-right py-3 px-4">Total</th>
                      <th className="text-right py-3 px-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredSales.map((sale) => (
                      <tr key={sale.id} className="border-b hover:bg-muted/50">
                        <td className="py-3 px-4">{sale.id}</td>
                        <td className="py-3 px-4">{format(new Date(sale.date), "dd MMM yyyy, hh:mm a")}</td>
                        <td className="py-3 px-4">{sale.items.length} items</td>
                        <td className="py-3 px-4 text-right">
                          {businessSettings.currency}
                          {sale.total.toFixed(2)}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <Button variant="ghost" size="sm" onClick={() => setSelectedSale(sale.id)}>
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      {/* Bill View Dialog */}
      <Dialog open={!!selectedSale} onOpenChange={(open) => !open && setSelectedSale(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {businessSettings.logoUrl ? (
                  <div className="w-6 h-6 relative">
                    <Image
                      src={businessSettings.logoUrl || "/placeholder.svg"}
                      alt={businessSettings.businessName}
                      fill
                      style={{ objectFit: "contain" }}
                    />
                  </div>
                ) : (
                  <CakeSlice className="h-5 w-5" />
                )}
                <span>Invoice</span>
              </div>
              <div className="flex items-center gap-2">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Share2 className="h-4 w-4 mr-2" />
                      Share
                      <ChevronDown className="h-4 w-4 ml-1" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={handleShareWhatsApp}>
                      <img
                        src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6b/WhatsApp.svg/1200px-WhatsApp.svg.png"
                        alt="WhatsApp"
                        className="h-4 w-4 mr-2"
                      />
                      Share via WhatsApp
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={handleShareSMS}>
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Share via SMS
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={handleDownloadBill}>
                      <Download className="h-4 w-4 mr-2" />
                      Download as Text
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                <Button variant="ghost" size="icon" onClick={() => setSelectedSale(null)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </DialogTitle>
          </DialogHeader>

          {sale && (
            <div className="space-y-4">
              <div className="text-center">
                <h2 className="text-xl font-bold" style={{ color: businessSettings.primaryColor }}>
                  {businessSettings.businessName}
                </h2>
                <p className="text-sm text-muted-foreground">{businessSettings.address}</p>
                <p className="text-sm text-muted-foreground">Tel: {businessSettings.phone}</p>
              </div>

              <div className="flex justify-between text-sm">
                <div>
                  <p>
                    <strong>Invoice:</strong> {sale.id}
                  </p>
                  <p>
                    <strong>Date:</strong> {format(new Date(sale.date), "dd MMM yyyy")}
                  </p>
                  <p>
                    <strong>Time:</strong> {format(new Date(sale.date), "hh:mm a")}
                  </p>
                </div>
                <div className="text-right">
                  <p>
                    <strong>Customer:</strong> Walk-in
                  </p>
                  <p>
                    <strong>Payment:</strong> UPI
                  </p>
                </div>
              </div>

              <div className="border-t border-b py-2">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-1">Item</th>
                      <th className="text-center py-1">Qty</th>
                      <th className="text-right py-1">Price</th>
                      <th className="text-right py-1">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sale.items.map((item, index) => (
                      <tr key={index} className="border-b border-dashed">
                        <td className="py-1">{item.name}</td>
                        <td className="text-center py-1">{item.quantity}</td>
                        <td className="text-right py-1">
                          {businessSettings.currency}
                          {item.price.toFixed(2)}
                        </td>
                        <td className="text-right py-1">
                          {businessSettings.currency}
                          {(item.price * item.quantity).toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>
                    {businessSettings.currency}
                    {sale.subtotal.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Tax ({businessSettings.taxRate}%):</span>
                  <span>
                    {businessSettings.currency}
                    {sale.tax.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between font-bold">
                  <span>Total:</span>
                  <span>
                    {businessSettings.currency}
                    {sale.total.toFixed(2)}
                  </span>
                </div>
              </div>

              <div className="flex flex-col items-center justify-center pt-4">
                <p className="text-sm font-medium mb-2">Scan to pay</p>
                <div className="bg-white p-2 rounded-lg">
                  <QRCode value={upiString} size={180} />
                </div>
                <p className="text-xs text-muted-foreground mt-2">UPI: {businessSettings.upiId}</p>
              </div>

              <div className="text-center text-xs text-muted-foreground pt-2">
                <p>Thank you for your business!</p>
                <p>Powered by {businessSettings.businessName}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      <Toaster />
    </div>
  )
}
