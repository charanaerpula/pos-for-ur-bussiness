"use client"

import { Calendar } from "@/components/ui/calendar"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Barcode,
  CakeSlice,
  Minus,
  Plus,
  Search,
  ShoppingCart,
  Trash2,
  X,
  DollarSign,
  Share2,
  Download,
  ChevronDown,
  MessageSquare,
  Filter,
  Check,
  Loader2,
  ShoppingBag,
  Tag,
  Clock,
} from "lucide-react"
import BarcodeScanner from "@/components/barcode-scanner"
import { Badge } from "@/components/ui/badge"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import QRCode from "@/components/qr-code"
import { useStore, type CartItem, type Product } from "@/lib/store"
import { toast } from "@/components/ui/use-toast"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { format } from "date-fns"
import Image from "next/image"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { cn } from "@/lib/utils"
import { ScrollArea } from "@/components/ui/scroll-area"

export default function BillingPage() {
  const { products, addSale, getTotalSales, getTodaySalesCount, businessSettings, sales, categories } = useStore()
  const [cart, setCart] = useState<CartItem[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [showScanner, setShowScanner] = useState(false)
  const [cartOpen, setCartOpen] = useState(false)
  const [billOpen, setBillOpen] = useState(false)
  const [billId, setBillId] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [isCheckingOut, setIsCheckingOut] = useState(false)
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")

  // Group products by category
  const productsByCategory = products.reduce(
    (acc, product) => {
      const category = product.category
      if (!acc[category]) {
        acc[category] = []
      }
      acc[category].push(product)
      return acc
    },
    {} as Record<string, Product[]>,
  )

  // Filter products based on search term and selected category
  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory ? product.category === selectedCategory : true
    return matchesSearch && matchesCategory
  })

  // Get category name from slug
  const getCategoryName = (slug: string) => {
    const category = categories.find((cat) => cat.slug === slug)
    return category ? category.name : slug
  }

  const addToCart = (product: Product) => {
    if (product.stock <= 0) {
      toast({
        title: "Out of Stock",
        description: `${product.name} is out of stock`,
        variant: "destructive",
      })
      return
    }

    setCart((prevCart) => {
      const existingItem = prevCart.find((item) => item.productId === product.id)

      if (existingItem) {
        // Check if we have enough stock
        if (existingItem.quantity >= product.stock) {
          toast({
            title: "Insufficient Stock",
            description: `Only ${product.stock} ${product.name} available`,
            variant: "destructive",
          })
          return prevCart
        }

        return prevCart.map((item) => (item.productId === product.id ? { ...item, quantity: item.quantity + 1 } : item))
      } else {
        return [
          ...prevCart,
          {
            productId: product.id,
            name: product.name,
            price: product.price,
            quantity: 1,
          },
        ]
      }
    })
  }

  const removeFromCart = (id: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.productId !== id))
  }

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity < 1) return

    // Check if we have enough stock
    const product = products.find((p) => p.id === id)
    if (product && newQuantity > product.stock) {
      toast({
        title: "Insufficient Stock",
        description: `Only ${product.stock} ${product.name} available`,
        variant: "destructive",
      })
      return
    }

    setCart((prevCart) => prevCart.map((item) => (item.productId === id ? { ...item, quantity: newQuantity } : item)))
  }

  const handleScan = (result: string) => {
    const product = products.find((p) => p.sku === result)
    if (product) {
      if (product.stock > 0) {
        addToCart(product)
        // Don't close the scanner in continuous mode
        // setShowScanner(false)

        // Show toast notification
        toast({
          title: "Product Added",
          description: `${product.name} added to cart`,
          duration: 2000,
        })
      } else {
        toast({
          title: "Out of Stock",
          description: `${product.name} is out of stock`,
          variant: "destructive",
          duration: 2000,
        })
      }
    } else {
      toast({
        title: "Product Not Found",
        description: "No product found with this barcode",
        variant: "destructive",
        duration: 2000,
      })
    }
  }

  const handleCheckout = () => {
    if (cart.length === 0) return

    setIsCheckingOut(true)

    // Process the sale with a small delay to show loading state
    setTimeout(() => {
      // Process the sale
      const newBillId = addSale(cart, subtotal, tax, total)
      setBillId(newBillId)
      setBillOpen(true)
      setCartOpen(false)
      setIsCheckingOut(false)
    }, 800)
  }

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const tax = subtotal * (businessSettings.taxRate / 100) // Use tax rate from settings
  const total = subtotal + tax
  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0)

  // Format date for bill
  const currentDate = new Date().toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  })

  // Format time for bill
  const currentTime = new Date().toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
  })

  // UPI payment string with dynamic amount
  const upiString = `upi://pay?pa=${businessSettings.upiId}&pn=${encodeURIComponent(businessSettings.businessName)}&am=${total.toFixed(0)}&cu=INR&tn=payment`

  // Clear cart after successful payment
  const handleCloseBill = () => {
    setBillOpen(false)
    setCart([])
  }

  const sale = sales.find((s) => s.id === billId)

  const handleShareWhatsApp = () => {
    if (!sale) return

    const items = sale.items
      .map(
        (item) =>
          `${item.name} x${item.quantity} - ${businessSettings.currency}${(item.price * item.quantity).toFixed(2)}`,
      )
      .join("\n")

    const billText = `
*INVOICE: ${sale.id}*
*Date:* ${format(new Date(sale.date), "dd MMM yyyy, hh:mm a")}

*ITEMS:*
${items}

*Subtotal:* ${businessSettings.currency}${sale.subtotal.toFixed(2)}
*Tax (${businessSettings.taxRate}%):* ${businessSettings.currency}${sale.tax.toFixed(2)}
*Total:* ${businessSettings.currency}${sale.total.toFixed(2)}

Thank you for your business!
Powered by ${businessSettings.businessName}
`.trim()

    // Encode the text for WhatsApp
    const encodedText = encodeURIComponent(billText)
    const whatsappUrl = `https://wa.me/?text=${encodedText}`

    // Open WhatsApp in a new tab
    window.open(whatsappUrl, "_blank")

    toast({
      title: "Bill shared",
      description: "The bill has been shared via WhatsApp",
    })
  }

  const handleDownloadBill = () => {
    if (!sale) return

    const items = sale.items
      .map(
        (item) =>
          `${item.name} x${item.quantity} - ${businessSettings.currency}${(item.price * item.quantity).toFixed(2)}`,
      )
      .join("\n")

    const billText = `
INVOICE: ${sale.id}
Date: ${format(new Date(), "dd MMM yyyy, hh:mm a")}

ITEMS:
${items}

Subtotal: ${businessSettings.currency}${sale.subtotal.toFixed(2)}
Tax (${businessSettings.taxRate}%): ${businessSettings.currency}${sale.tax.toFixed(2)}
Total: ${businessSettings.currency}${sale.total.toFixed(2)}

Thank you for your business!
Powered by ${businessSettings.businessName}
  `.trim()

    // Create a blob and download it
    const blob = new Blob([billText], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `Invoice-${sale.id}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "Bill downloaded",
      description: "The bill has been downloaded as a text file",
    })
  }

  const handleShareSMS = () => {
    if (!sale) return

    const items = sale.items
      .map(
        (item) =>
          `${item.name} x${item.quantity} - ${businessSettings.currency}${(item.price * item.quantity).toFixed(2)}`,
      )
      .join(", ")

    const billText = `Invoice: ${sale.id}. Total: ${businessSettings.currency}${sale.total.toFixed(2)}. Items: ${items}. Thank you for your business!`

    // Create SMS URI
    const smsUri = `sms:?body=${encodeURIComponent(billText)}`

    // Open in a new tab
    window.open(smsUri, "_blank")

    toast({
      title: "SMS prepared",
      description: "SMS app has been opened with the bill details",
    })
  }

  // Auto-open cart when items are added (on mobile only)
  useEffect(() => {
    if (cart.length > 0 && window.innerWidth < 768 && !cartOpen) {
      setCartOpen(true)
    }
  }, [cart.length])

  return (
    <div className="page-container">
      <header className="page-header">
        <div className="container mx-auto p-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold">{businessSettings.businessName}</h1>
              <p className="text-muted-foreground">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
            </div>

            {/* Stats cards */}
            <div className="flex flex-row gap-3">
              <Card className="data-card">
                <CardContent className="p-3">
                  <div className="flex items-center gap-2">
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <DollarSign className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Today's Sales</p>
                      <p className="text-base font-bold">
                        {businessSettings.currency}
                        {getTotalSales().toLocaleString("en-IN")}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="data-card">
                <CardContent className="p-3">
                  <div className="flex items-center gap-2">
                    <div className="h-8 w-8 rounded-full bg-green-500/10 flex items-center justify-center">
                      <ShoppingBag className="h-4 w-4 text-green-500" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Orders</p>
                      <p className="text-base font-bold">{getTodaySalesCount()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Mobile Cart Button */}
              <Sheet open={cartOpen} onOpenChange={setCartOpen}>
                <SheetTrigger asChild>
                  <Button variant="outline" size="icon" className="relative md:hidden h-[52px] w-[52px]">
                    <ShoppingCart className="h-5 w-5" />
                    {itemCount > 0 && (
                      <Badge className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center">
                        {itemCount}
                      </Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-full sm:w-[400px] p-0">
                  <SheetHeader className="p-4 border-b">
                    <SheetTitle className="flex items-center">
                      <ShoppingCart className="mr-2 h-5 w-5" />
                      Current Order
                      {itemCount > 0 && (
                        <Badge variant="secondary" className="ml-2">
                          {itemCount} {itemCount === 1 ? "item" : "items"}
                        </Badge>
                      )}
                    </SheetTitle>
                  </SheetHeader>
                  <ScrollArea className="flex-1 h-[calc(100vh-180px)]">
                    <div className="p-4">
                      {cart.length === 0 ? (
                        <div className="text-center py-6 text-muted-foreground">
                          <ShoppingCart className="h-12 w-12 mx-auto mb-3 opacity-20" />
                          <p>Your cart is empty</p>
                          <p className="text-sm">Add products to get started</p>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {cart.map((item) => (
                            <div key={item.productId} className="flex justify-between items-center border-b pb-3">
                              <div className="flex-1">
                                <p className="font-medium">{item.name}</p>
                                <p className="text-sm text-muted-foreground">
                                  {businessSettings.currency}
                                  {item.price.toFixed(2)} each
                                </p>
                              </div>
                              <div className="flex items-center gap-2">
                                <Button
                                  variant="outline"
                                  size="icon"
                                  className="h-7 w-7"
                                  onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                                >
                                  <Minus className="h-3 w-3" />
                                </Button>
                                <span className="w-6 text-center">{item.quantity}</span>
                                <Button
                                  variant="outline"
                                  size="icon"
                                  className="h-7 w-7"
                                  onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                                >
                                  <Plus className="h-3 w-3" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7 text-red-500"
                                  onClick={() => removeFromCart(item.productId)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {cart.length > 0 && (
                        <div className="mt-6 space-y-2">
                          <div className="flex justify-between">
                            <span>Subtotal</span>
                            <span>
                              {businessSettings.currency}
                              {subtotal.toFixed(2)}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span>Tax ({businessSettings.taxRate}%)</span>
                            <span>
                              {businessSettings.currency}
                              {tax.toFixed(2)}
                            </span>
                          </div>
                          <div className="flex justify-between font-bold text-lg">
                            <span>Total</span>
                            <span>
                              {businessSettings.currency}
                              {total.toFixed(2)}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                  <div className="p-4 border-t">
                    <div className="grid grid-cols-2 gap-2">
                      <Button variant="outline" onClick={() => setCart([])} disabled={cart.length === 0}>
                        Clear
                      </Button>
                      <Button disabled={cart.length === 0 || isCheckingOut} onClick={handleCheckout}>
                        {isCheckingOut ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          "Checkout"
                        )}
                      </Button>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>

          <div className="mt-6">
            <h2 className="text-2xl font-bold">Point of Sale</h2>
          </div>
        </div>
      </header>

      <main className="page-content">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="data-card">
              <CardHeader className="pb-3 flex flex-row items-center justify-between">
                <CardTitle>Products</CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => setShowScanner(!showScanner)}>
                    <Barcode className="mr-2 h-4 w-4" />
                    {showScanner ? "Hide Scanner" : "Scan Barcode"}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {showScanner ? (
                  <div className="p-4 border rounded-lg mb-4 bg-muted/30 dark:bg-gray-800/30">
                    <h3 className="text-lg font-medium mb-2">Scan Products</h3>
                    <BarcodeScanner onScan={handleScan} continuous={true} />
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex flex-col sm:flex-row gap-3">
                      <div className="relative flex-1">
                        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                          type="search"
                          placeholder="Search products by name or barcode..."
                          className="w-full pl-8"
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                        />
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="outline" className="w-full sm:w-auto">
                            <Filter className="mr-2 h-4 w-4" />
                            {selectedCategory ? getCategoryName(selectedCategory) : "All Categories"}
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-[200px]">
                          <DropdownMenuItem
                            onClick={() => setSelectedCategory(null)}
                            className="flex items-center justify-between"
                          >
                            All Categories
                            {selectedCategory === null && <Check className="h-4 w-4 ml-2" />}
                          </DropdownMenuItem>
                          {categories.map((category) => (
                            <DropdownMenuItem
                              key={category.id}
                              onClick={() => setSelectedCategory(category.slug)}
                              className="flex items-center justify-between capitalize"
                            >
                              {category.name}
                              {selectedCategory === category.slug && <Check className="h-4 w-4 ml-2" />}
                            </DropdownMenuItem>
                          ))}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>

                    {products.length === 0 ? (
                      <div className="text-center py-6">
                        <p className="text-muted-foreground mb-4">No products in inventory</p>
                        <Button asChild>
                          <a href="/inventory/add">Add Products</a>
                        </Button>
                      </div>
                    ) : filteredProducts.length === 0 ? (
                      <div className="text-center py-6 text-muted-foreground">No products match your search</div>
                    ) : (
                      <Tabs
                        defaultValue="grid"
                        className="w-full"
                        onValueChange={(value) => setViewMode(value as "grid" | "list")}
                      >
                        <div className="flex justify-end mb-4">
                          <TabsList className="grid w-[160px] grid-cols-2">
                            <TabsTrigger value="grid" className="flex items-center justify-center">
                              <div className="grid grid-cols-2 gap-0.5">
                                <div className="h-1.5 w-1.5 rounded-sm bg-current"></div>
                                <div className="h-1.5 w-1.5 rounded-sm bg-current"></div>
                                <div className="h-1.5 w-1.5 rounded-sm bg-current"></div>
                                <div className="h-1.5 w-1.5 rounded-sm bg-current"></div>
                              </div>
                              <span className="ml-2">Grid</span>
                            </TabsTrigger>
                            <TabsTrigger value="list" className="flex items-center justify-center">
                              <div className="flex flex-col gap-0.5">
                                <div className="h-1 w-5 rounded-sm bg-current"></div>
                                <div className="h-1 w-5 rounded-sm bg-current"></div>
                                <div className="h-1 w-5 rounded-sm bg-current"></div>
                              </div>
                              <span className="ml-2">List</span>
                            </TabsTrigger>
                          </TabsList>
                        </div>

                        <TabsContent value="grid" className="mt-0">
                          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                            {filteredProducts.map((product) => (
                              <Button
                                key={product.id}
                                variant="outline"
                                className={cn(
                                  "h-auto py-4 px-4 flex flex-col items-start justify-start text-left",
                                  product.stock <= 0 ? "opacity-50 cursor-not-allowed" : "",
                                  "border-none shadow-sm hover:shadow-md transition-shadow dark:bg-card dark:hover:bg-accent",
                                )}
                                onClick={() => {
                                  if (product.stock > 0) {
                                    addToCart(product)
                                  }
                                }}
                              >
                                <span className="font-medium line-clamp-2">{product.name}</span>
                                <div className="flex justify-between w-full mt-2">
                                  <span className="text-lg font-bold text-primary">
                                    {businessSettings.currency}
                                    {product.price.toFixed(2)}
                                  </span>
                                  <Badge variant={product.stock <= 0 ? "destructive" : "outline"} className="ml-auto">
                                    {product.stock <= 0 ? "Out of stock" : `${product.stock} left`}
                                  </Badge>
                                </div>
                                <Badge variant="secondary" className="mt-2 capitalize">
                                  {getCategoryName(product.category)}
                                </Badge>
                              </Button>
                            ))}
                          </div>
                        </TabsContent>

                        <TabsContent value="list" className="mt-0">
                          <div className="space-y-2">
                            {filteredProducts.map((product) => (
                              <div
                                key={product.id}
                                className={cn(
                                  "flex items-center justify-between p-3 rounded-md",
                                  product.stock <= 0
                                    ? "opacity-50 cursor-not-allowed"
                                    : "cursor-pointer hover:bg-accent",
                                  "border shadow-sm dark:bg-card",
                                )}
                                onClick={() => {
                                  if (product.stock > 0) {
                                    addToCart(product)
                                  }
                                }}
                              >
                                <div className="flex-1">
                                  <div className="flex items-center">
                                    <span className="font-medium">{product.name}</span>
                                    <Badge variant="secondary" className="ml-2 capitalize">
                                      {getCategoryName(product.category)}
                                    </Badge>
                                  </div>
                                  <div className="text-sm text-muted-foreground">SKU: {product.sku}</div>
                                </div>
                                <div className="flex items-center gap-4">
                                  <Badge variant={product.stock <= 0 ? "destructive" : "outline"}>
                                    {product.stock <= 0 ? "Out of stock" : `${product.stock} left`}
                                  </Badge>
                                  <span className="text-lg font-bold text-primary">
                                    {businessSettings.currency}
                                    {product.price.toFixed(2)}
                                  </span>
                                  {product.stock > 0 && (
                                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                                      <Plus className="h-4 w-4" />
                                    </Button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </TabsContent>
                      </Tabs>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Desktop Cart View */}
          <div className="hidden md:block lg:col-span-1">
            <Card className="data-card sticky top-20">
              <CardHeader className="pb-3 border-b">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center">
                    <ShoppingCart className="mr-2 h-5 w-5" />
                    Current Order
                  </CardTitle>
                  {itemCount > 0 && (
                    <Badge variant="secondary">
                      {itemCount} {itemCount === 1 ? "item" : "items"}
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="p-0">
                {cart.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <ShoppingCart className="h-12 w-12 mx-auto mb-3 opacity-20" />
                    <p>Your cart is empty</p>
                    <p className="text-sm">Add products to get started</p>
                  </div>
                ) : (
                  <ScrollArea className="max-h-[calc(100vh-300px)]">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Item</TableHead>
                          <TableHead className="text-right">Qty</TableHead>
                          <TableHead className="text-right">Price</TableHead>
                          <TableHead className="w-[50px]"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {cart.map((item) => (
                          <TableRow key={item.productId}>
                            <TableCell className="font-medium">{item.name}</TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6"
                                  onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                                >
                                  <Minus className="h-3 w-3" />
                                </Button>
                                <span className="w-8 text-center">{item.quantity}</span>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6"
                                  onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                                >
                                  <Plus className="h-3 w-3" />
                                </Button>
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              {businessSettings.currency}
                              {(item.price * item.quantity).toFixed(2)}
                            </TableCell>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={() => removeFromCart(item.productId)}
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                )}

                {cart.length > 0 && (
                  <div className="p-4 space-y-3 border-t">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span>
                        {businessSettings.currency}
                        {subtotal.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Tax ({businessSettings.taxRate}%)</span>
                      <span>
                        {businessSettings.currency}
                        {tax.toFixed(2)}
                      </span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-bold text-lg">
                      <span>Total</span>
                      <span>
                        {businessSettings.currency}
                        {total.toFixed(2)}
                      </span>
                    </div>
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-between p-4 border-t">
                <Button variant="outline" className="w-[48%]" onClick={() => setCart([])} disabled={cart.length === 0}>
                  Clear
                </Button>
                <Button className="w-[48%]" disabled={cart.length === 0 || isCheckingOut} onClick={handleCheckout}>
                  {isCheckingOut ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    "Checkout"
                  )}
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>

      {/* Bill Generation Dialog */}
      <Dialog open={billOpen} onOpenChange={handleCloseBill}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {businessSettings.logoUrl ? (
                  <div className="w-6 h-6 relative">
                    <Image
                      src={businessSettings.logoUrl || "/placeholder.svg"}
                      alt={businessSettings.businessName}
                      fill
                      style={{ objectFit: "contain" }}
                    />
                  </div>
                ) : (
                  <CakeSlice className="h-5 w-5" />
                )}
                <span>Invoice #{billId}</span>
              </div>
              <div className="flex items-center gap-2">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Share2 className="h-4 w-4 mr-2" />
                      Share
                      <ChevronDown className="h-4 w-4 ml-1" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={handleShareWhatsApp}>
                      <img
                        src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6b/WhatsApp.svg/1200px-WhatsApp.svg.png"
                        alt="WhatsApp"
                        className="h-4 w-4 mr-2"
                      />
                      Share via WhatsApp
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={handleShareSMS}>
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Share via SMS
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={handleDownloadBill}>
                      <Download className="h-4 w-4 mr-2" />
                      Download as Text
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                <Button variant="ghost" size="icon" onClick={handleCloseBill}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="text-center">
              <h2 className="text-xl font-bold" style={{ color: businessSettings.primaryColor }}>
                {businessSettings.businessName}
              </h2>
              <p className="text-sm text-muted-foreground">{businessSettings.address}</p>
              <p className="text-sm text-muted-foreground">Tel: {businessSettings.phone}</p>
            </div>

            <div className="flex justify-between text-sm">
              <div>
                <p className="flex items-center gap-1">
                  <Tag className="h-3.5 w-3.5" />
                  <strong>Invoice:</strong> {billId}
                </p>
                <p className="flex items-center gap-1">
                  <Calendar className="h-3.5 w-3.5" />
                  <strong>Date:</strong> {currentDate}
                </p>
                <p className="flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" />
                  <strong>Time:</strong> {currentTime}
                </p>
              </div>
              <div className="text-right">
                <p>
                  <strong>Customer:</strong> Walk-in
                </p>
                <p>
                  <strong>Payment:</strong> UPI
                </p>
              </div>
            </div>

            <div className="border-t border-b py-2">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-1">Item</th>
                    <th className="text-center py-1">Qty</th>
                    <th className="text-right py-1">Price</th>
                    <th className="text-right py-1">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {cart.map((item) => (
                    <tr key={item.productId} className="border-b border-dashed">
                      <td className="py-1">{item.name}</td>
                      <td className="text-center py-1">{item.quantity}</td>
                      <td className="text-right py-1">
                        {businessSettings.currency}
                        {item.price.toFixed(2)}
                      </td>
                      <td className="text-right py-1">
                        {businessSettings.currency}
                        {(item.price * item.quantity).toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>
                  {businessSettings.currency}
                  {subtotal.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Tax ({businessSettings.taxRate}%):</span>
                <span>
                  {businessSettings.currency}
                  {tax.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between font-bold">
                <span>Total:</span>
                <span>
                  {businessSettings.currency}
                  {total.toFixed(2)}
                </span>
              </div>
            </div>

            <div className="flex flex-col items-center justify-center pt-4">
              <p className="text-sm font-medium mb-2">Scan to pay</p>
              <div className="bg-white p-2 rounded-lg">
                <QRCode value={upiString} size={180} />
              </div>
              <p className="text-xs text-muted-foreground mt-2">UPI: {businessSettings.upiId}</p>
            </div>

            <div className="text-center text-xs text-muted-foreground pt-2">
              <p>Thank you for your business!</p>
              <p>Powered by {businessSettings.businessName}</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
