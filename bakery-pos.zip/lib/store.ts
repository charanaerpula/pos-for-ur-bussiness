import { create } from "zustand"
import { persist } from "zustand/middleware"

export type Product = {
  id: string
  name: string
  sku: string
  price: number
  cost: number
  stock: number
  category: string
  description?: string
}

export type CartItem = {
  productId: string
  name: string
  price: number
  quantity: number
}

export type Sale = {
  id: string
  items: CartItem[]
  subtotal: number
  tax: number
  total: number
  date: Date
}

export type Category = {
  id: string
  name: string
  slug: string
}

export type BusinessSettings = {
  businessName: string
  tagline: string
  address: string
  phone: string
  currency: string
  taxRate: number
  upiId: string
  logoUrl?: string
  primaryColor: string
  adminPassword: string
}

export type UserRole = "admin" | "employee" | "guest"

export type User = {
  id: string
  name: string
  role: UserRole
  pin: string
}

interface AuthState {
  currentUser: User | null
  isAuthenticated: boolean
  role: UserRole
  login: (pin: string) => boolean
  adminLogin: (password: string) => boolean
  logout: () => void
}

interface StoreState {
  products: Product[]
  sales: Sale[]
  categories: Category[]
  businessSettings: BusinessSettings
  users: User[]
  auth: AuthState
  addProduct: (product: Omit<Product, "id">) => void
  updateProduct: (id: string, product: Partial<Product>) => void
  deleteProduct: (id: string) => void
  updateStock: (id: string, quantity: number) => void
  addSale: (items: CartItem[], subtotal: number, tax: number, total: number) => string
  getTotalSales: () => number
  getTodaySalesCount: () => number
  getLowStockProducts: () => Product[]
  resetProducts: () => void
  resetSales: () => void
  resetAllData: () => void
  updateBusinessSettings: (settings: Partial<BusinessSettings>) => void
  addUser: (user: Omit<User, "id">) => void
  updateUser: (id: string, user: Partial<User>) => void
  deleteUser: (id: string) => void
  addCategory: (category: Omit<Category, "id">) => void
  updateCategory: (id: string, category: Partial<Category>) => void
  deleteCategory: (id: string) => void
}

const defaultBusinessSettings: BusinessSettings = {
  businessName: "Prime Bakers",
  tagline: "Fresh baked goods daily",
  address: "123 Baker Street, Cityville",
  phone: "(123) 456-7890",
  currency: "₹",
  taxRate: 8,
  upiId: "9912078905@ybl",
  primaryColor: "hsl(221.2 83.2% 53.3%)",
  adminPassword: "admin123", // Default admin password
}

// Only include a default admin user
const defaultUsers: User[] = [
  {
    id: "admin-1",
    name: "Admin",
    role: "admin",
    pin: "1234",
  },
]

// Default categories for bakery items
const defaultCategories: Category[] = [
  {
    id: "cat-1",
    name: "Bread",
    slug: "bread",
  },
  {
    id: "cat-2",
    name: "Pastries",
    slug: "pastries",
  },
  {
    id: "cat-3",
    name: "Cakes",
    slug: "cakes",
  },
  {
    id: "cat-4",
    name: "Cookies",
    slug: "cookies",
  },
  {
    id: "cat-5",
    name: "Other",
    slug: "other",
  },
]

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      products: [], // Start with empty products
      sales: [], // Start with empty sales
      categories: defaultCategories,
      businessSettings: defaultBusinessSettings,
      users: defaultUsers,

      auth: {
        currentUser: null,
        isAuthenticated: false,
        role: "guest",

        login: (pin: string) => {
          const user = get().users.find((u) => u.pin === pin)
          if (user) {
            set((state) => ({
              auth: {
                ...state.auth,
                currentUser: user,
                isAuthenticated: true,
                role: user.role,
              },
            }))
            return true
          }
          return false
        },

        adminLogin: (password: string) => {
          if (password === get().businessSettings.adminPassword) {
            const adminUser = get().users.find((u) => u.role === "admin") || {
              id: "admin-default",
              name: "Administrator",
              role: "admin",
              pin: "0000",
            }

            set((state) => ({
              auth: {
                ...state.auth,
                currentUser: adminUser,
                isAuthenticated: true,
                role: "admin",
              },
            }))
            return true
          }
          return false
        },

        logout: () => {
          // Ensure we completely reset the auth state
          set((state) => ({
            auth: {
              ...state.auth,
              currentUser: null,
              isAuthenticated: false,
              role: "guest",
            },
          }))
        },
      },

      addProduct: (product) => {
        const id = Date.now().toString()
        set((state) => ({
          products: [...state.products, { ...product, id }],
        }))
        return id
      },

      updateProduct: (id, updatedProduct) => {
        set((state) => ({
          products: state.products.map((product) => (product.id === id ? { ...product, ...updatedProduct } : product)),
        }))
      },

      deleteProduct: (id) => {
        set((state) => ({
          products: state.products.filter((product) => product.id !== id),
        }))
      },

      updateStock: (id, quantity) => {
        set((state) => ({
          products: state.products.map((product) =>
            product.id === id ? { ...product, stock: Math.max(0, product.stock - quantity) } : product,
          ),
        }))
      },

      addSale: (items, subtotal, tax, total) => {
        const id = `INV-${Math.floor(Math.random() * 10000)
          .toString()
          .padStart(4, "0")}`

        // Update stock for each product
        items.forEach((item) => {
          get().updateStock(item.productId, item.quantity)
        })

        // Add the sale
        set((state) => ({
          sales: [
            ...state.sales,
            {
              id,
              items,
              subtotal,
              tax,
              total,
              date: new Date(),
            },
          ],
        }))

        return id
      },

      getTotalSales: () => {
        return get().sales.reduce((total, sale) => total + sale.total, 0)
      },

      getTodaySalesCount: () => {
        const today = new Date()
        today.setHours(0, 0, 0, 0)

        return get().sales.filter((sale) => {
          const saleDate = new Date(sale.date)
          saleDate.setHours(0, 0, 0, 0)
          return saleDate.getTime() === today.getTime()
        }).length
      },

      getLowStockProducts: () => {
        return get().products.filter((product) => product.stock < 10)
      },

      resetProducts: () => {
        set({ products: [] })
      },

      resetSales: () => {
        set({ sales: [] })
      },

      resetAllData: () => {
        set({
          products: [],
          sales: [],
          categories: defaultCategories,
          businessSettings: defaultBusinessSettings,
          users: defaultUsers,
          auth: {
            ...get().auth,
            currentUser: null,
            isAuthenticated: false,
            role: "guest",
          },
        })
      },

      updateBusinessSettings: (settings) => {
        set((state) => ({
          businessSettings: {
            ...state.businessSettings,
            ...settings,
          },
        }))
      },

      addUser: (user) => {
        const id = Date.now().toString()
        set((state) => ({
          users: [...state.users, { ...user, id }],
        }))
      },

      updateUser: (id, updatedUser) => {
        set((state) => ({
          users: state.users.map((user) => (user.id === id ? { ...user, ...updatedUser } : user)),
        }))
      },

      deleteUser: (id) => {
        // Don't allow deleting the last admin
        const users = get().users
        const adminUsers = users.filter((user) => user.role === "admin")
        const userToDelete = users.find((user) => user.id === id)

        if (userToDelete?.role === "admin" && adminUsers.length <= 1) {
          return // Don't delete the last admin
        }

        set((state) => ({
          users: state.users.filter((user) => user.id !== id),
        }))
      },

      addCategory: (category) => {
        const id = Date.now().toString()
        set((state) => ({
          categories: [...state.categories, { ...category, id }],
        }))
      },

      updateCategory: (id, updatedCategory) => {
        set((state) => ({
          categories: state.categories.map((category) =>
            category.id === id ? { ...category, ...updatedCategory } : category,
          ),
        }))
      },

      deleteCategory: (id) => {
        // Check if any products are using this category
        const products = get().products
        const categoryInUse = products.some(
          (product) => product.category === get().categories.find((cat) => cat.id === id)?.slug,
        )

        if (categoryInUse) {
          return // Don't delete categories in use
        }

        set((state) => ({
          categories: state.categories.filter((category) => category.id !== id),
        }))
      },
    }),
    {
      name: "business-storage",
    },
  ),
)
